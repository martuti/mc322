package lab01;

import java.util.List;
import java.util.ArrayList;

/**
 * Classe principal para demonstração da implementação do sistema de eventos.
 * Código gerado com o auxilio de uma IA
 * @author Gabriel Leite - 216180
 * @author Caio Rhoden - 214129
 * @author Anna Carolina Martuti - 186723
 */
public class App {

     /**
     * Construtor padrão da classe App.
     * Como essa classe contém apenas o método main, o construtor é vazio.
     */
    public App() {
        // Construtor vazio, pois a classe serve apenas para execução
    }
    /**
     * Método principal para execução do programa.
     * Demonstra a criação e manipulação de eventos e ingressos.
     * 
     * @param args argumentos da linha de comando
     */
    public static void main(String[] args) {

        System.out.println("PASSO 1: Tipos de Ingressos");
        
        // Criando um local para os eventos
        Local local = new Local("Allianz Parque", 300);
        
        // Criando eventos de diferentes categorias
        EventoShow eventoShow = new EventoShow("Show de Rock", local, 100, "Música", "10/11/2025", "Banda X");
        EventoFestival eventoFestival = new EventoFestival("Festival de Música", local, 80, "Música", "15/11/2025", "DJ Y", "Empresa X");
        EventoTeatro eventoTeatro = new EventoTeatro("Peça de Teatro", local, 50, "Teatro", "20/11/2025", "O Rei Leão", "Simba");
        EventoEsporte eventoEsporte = new EventoEsporte("Jogo de Futebol", local, 40, "Esporte", "25/11/2025", "Time A", "Time B");
        
        // Criando ingressos para um evento
        Ingresso ingressoInteira = new IngressoInteira(eventoShow);
        Ingresso ingressoMeia = new IngressoMeia(eventoShow);
        Ingresso ingressoVIP = new IngressoVIP(eventoShow);
        
        // Exibindo preços dos ingressos
        System.out.println("Preço do Ingresso Inteira: R$ " + ingressoInteira.getPreco());
        System.out.println("Preço do Ingresso Meia: R$ " + ingressoMeia.getPreco());
        System.out.println("Preço do Ingresso VIP: R$ " + ingressoVIP.getPreco());

        System.out.println("-------------------------------------------");

        System.out.println("PASSO 2: Categorias de Eventos");
        
        // Exibindo detalhes dos eventos
        System.out.println("Detalhes do Evento Show:");
        eventoShow.exibirDetalhes();
        System.out.println();
        
        System.out.println("Detalhes do Evento Festival:");
        eventoFestival.exibirDetalhes();
        System.out.println();
        
        System.out.println("Detalhes do Evento Teatro:");
        eventoTeatro.exibirDetalhes();
        System.out.println();
        
        System.out.println("Detalhes do Evento Esportivo:");
        eventoEsporte.exibirDetalhes();
        System.out.println();
        System.out.println("-------------------------------------------");

        System.out.println("PASSO 3: Calculando o Faturamento do Evento");
        
        // Lista para armazenar ingressos vendidos
        List<Ingresso> ingressosVendidos = new ArrayList<>();
        ingressosVendidos.add(ingressoInteira);
        ingressosVendidos.add(ingressoMeia);
        ingressosVendidos.add(ingressoVIP);
        
        // Associando ingressos aos eventos
        eventoShow.adicionarIngressoVendido(ingressoInteira);
        eventoFestival.adicionarIngressoVendido(ingressoMeia);
        eventoTeatro.adicionarIngressoVendido(ingressoVIP);
        
        // Exibindo faturamento dos eventos
        System.out.println("Faturamento do Evento Show: R$ " + eventoShow.calcularFaturamento());
        System.out.println("Faturamento do Evento Festival: R$ " + eventoFestival.calcularFaturamento());
        System.out.println("Faturamento do Evento Teatro: R$ " + eventoTeatro.calcularFaturamento());

        System.out.println("-------------------------------------------");

        System.out.println("PASSO 4: Histórico de Eventos");

        // Criando um histórico de eventos
        HistoricoEventos historico = new HistoricoEventos();
        
        // Adicionando eventos ao histórico
        historico.adicionarEvento(eventoShow);
        historico.adicionarEvento(eventoFestival);
        historico.adicionarEvento(eventoTeatro);
        historico.adicionarEvento(eventoEsporte);
        
        List<Evento> eventos = historico.getEventos();
        System.out.println("Eventos cadastrados no histórico:");
        for (Evento evento : eventos) {
            System.out.println(evento.getNome());
        }

        System.out.println("-------------------------------------------");


        System.out.println("PASSO 5: BUSCA");

        // Buscando eventos por data
        String dataBusca = "10/11/2025";
        List<Evento> eventosPorData = historico.buscarEventosPorData(dataBusca);
        System.out.println("Eventos na data " + dataBusca + ":");
        for (Evento evento : eventosPorData) {
            System.out.println(evento.getNome());
        }
        
        System.out.println("-------------------------------------------");
        
    }
}
