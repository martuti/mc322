/**
 * Classe Evento
 * 
 * Representa um evento com nome, local, preço do ingresso e lista de ingressos vendidos.
 * 
 * Comentários e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Gabriel Leite - 216180
 * @author Caio Rhoden - 214129
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

import java.util.List;
import java.util.ArrayList;

/**
 * Classe abstrata que define a estrutura básica de um Evento.
 */
public abstract class Evento {
    
    /** 
     * Local onde o evento será realizado.
     */
    protected Local local;
    private String nome;
    private double precoIngresso;
    private List<Ingresso> ingressosVendidos;
    private String categoria;
    private String data;

    /**
     * Construtor da classe Evento.
     * 
     * @param local         o local onde será realizado
     * @param nome          o nome do evento
     * @param precoIngresso o valor do ingresso
     * @param 
     */
    public Evento(String nome, Local local, double precoIngresso, String categoria, String data) {
        this.nome = nome;
        this.local = local;
        this.precoIngresso = precoIngresso;
        this.ingressosVendidos = new ArrayList<>();
        this.categoria = categoria;
        this.data = data;

    }

    /**
     * Obtém o nome do evento.
     * 
     * @return o nome do evento
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do evento.
     * 
     * @param nome o novo nome do evento
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Obtém o preço do ingresso do evento.
     * 
     * @return o preço do ingresso
     */
    public double getPrecoIngresso() {
        return precoIngresso;
    }

    /**
     * Define o preço do ingresso do evento.
     * 
     * @param precoIngresso o novo valor do ingresso
     */
    public void setPrecoIngresso(double precoIngresso) {
        this.precoIngresso = precoIngresso;
    }

    /**
     * Adiciona um ingresso vendido à lista de ingressos.
     * 
     * @param ingresso o ingresso vendido a ser adicionado
     */
    public void adicionarIngressoVendido(Ingresso ingresso) {
        ingressosVendidos.add(ingresso);
    }
    
    /**
     * Obtém a categoria.
     * 
     * @return o nome da categoria
     */
    public String getCategoria() {
        return categoria;
    }


     /**
     * Obtém a data.
     * 
     * @return a data do evento
     */
    public String getData() {
        return data;
    }

    /**
     * Calcula o faturamento total do evento com base nos ingressos vendidos.
     * 
     * @return o valor total arrecadado com a venda de ingressos
     */

    public double calcularFaturamento() {
        double total = 0;
        for (Ingresso ingresso : ingressosVendidos) {
            total += ingresso.getPreco();
        }
        return total;
    }

    /**
     * Adiciona um ingresso vendido à lista de ingressos.
     * 
     * @param ingresso o ingresso vendido a ser adicionado
     */
    public void IngressoVendido(Ingresso ingresso) {
        ingressosVendidos.add(ingresso);
    }

    /**
     * Retorna a lista de ingressos vendidos para este evento.
     * 
     * @return a lista de ingressos vendidos
     */
    public List<Ingresso> getIngressosVendidos() {
        return ingressosVendidos;
    }

    /**
     * Adiciona um ingresso à lista de ingressos vendidos e associa ao usuário.
     * 
     * @param ingresso o ingresso a ser adicionado
     * @param usuario  o usuário que comprou o ingresso
     */
    public void adicionarIngresso(Ingresso ingresso, Usuario usuario) {
        ingressosVendidos.add(ingresso);
        usuario.adicionarIngresso(ingresso); // Garante que o usuário também registre o ingresso comprado
    }
}
