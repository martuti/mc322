/**
 * Classe EventoEsporte
 * 
 * Representa um evento esportivo com dois oponentes.
 * 
 * Comentários, criação de funções relacionadas ao filtrar e outras documentações e foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

/**
 * Classe que modela um evento esportivo, estendendo a classe Evento.
 */
public class EventoEsporte extends Evento implements FiltroEventos {
    
    private String oponente1;
    private String oponente2;

    /**
     * Construtor da classe EventoEsporte.
     * 
     * @param nome          o nome do evento esportivo
     * @param local         o local onde será realizado
     * @param precoIngresso o valor do ingresso
     * @param categoria     a categoria do evento
     * @param data          a data do evento
     * @param oponente1     o nome do primeiro oponente
     * @param oponente2     o nome do segundo oponente
     */
    
    public EventoEsporte(String nome, Local local, double precoIngresso, String categoria, String data, String oponente1, String oponente2) {
        super(nome, local, precoIngresso, categoria, data);
        this.oponente1 = oponente1;
        this.oponente2 = oponente2;
    }

    /**
     * Obtém o nome do primeiro oponente.
     * 
     * @return o nome do primeiro oponente
     */
    public String getOponente1() {
        return oponente1;
    }

    /**
     * Obtém o nome do segundo oponente.
     * 
     * @return o nome do segundo oponente
     */
    public String getOponente2() {
        return oponente2;
    }

    /**
     * Método que filtra eventos esportivos com base nos oponentes.
     * Retorna {@code true} se o evento fornecido for do tipo {@code EventoEsporte} 
     * e compartilhar pelo menos um dos oponentes com o evento atual.
     * 
     * @param evento Evento a ser comparado.
     * @return {@code true} se o evento possuir pelo menos um oponente em comum, 
     *         {@code false} caso contrário.
     */
    @Override
    public boolean filtrar(Evento evento) {
        if (evento instanceof EventoEsporte) {
            EventoEsporte outro = (EventoEsporte) evento;
            return this.oponente1.equalsIgnoreCase(outro.oponente1) || this.oponente2.equalsIgnoreCase(outro.oponente2);
        }
        return false;
    }


    /**
     * Método específico para exibir detalhes do evento esportivo.
     * 
     * Exibe os oponentes e a data do evento.
     * 
     */
    public void exibirDetalhes() {
        System.out.println("Evento esportivo: " + getNome());
        System.out.println("Local: " + local.getNome());
        System.out.println("Data: " + getData());
        System.out.println("Oponentes: " + getOponente1() + " vs. " + getOponente2());
        System.out.println("Preço do ingresso: R$ " + getPrecoIngresso());
    }
}
