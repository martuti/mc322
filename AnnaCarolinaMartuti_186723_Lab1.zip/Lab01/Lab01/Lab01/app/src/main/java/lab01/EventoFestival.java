/**
 * Classe EventoFestival
 * 
 * Representa um evento do tipo festival, contendo informações sobre traje e atração especial.
 * 
 * Comentários, criação de funções relacionadas ao filtrar e outras documentações e foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

/**
 * Classe que modela um evento do tipo festival, estendendo a classe Evento.
 */
public class EventoFestival extends Evento implements FiltroEventos{
    
    private String traje;
    private String atracao_especial;

    /**
     * Construtor da classe EventoFestival.
     * 
     * @param nome              o nome do festival
     * @param local             o local onde será realizado
     * @param precoIngresso     o valor do ingresso
     * @param categoria         a categoria do evento
     * @param data              a data do evento
     * @param traje             o traje recomendado
     * @param atracao_especial  a atração especial do evento
     */
    public EventoFestival(String nome, Local local, double precoIngresso, String categoria, String data, String traje, String atracao_especial) {
        super(nome, local, precoIngresso, categoria, data);
        this.traje = traje;
        this.atracao_especial = atracao_especial;
    }

    /**
     * Obtém o traje recomendado para o festival.
     * 
     * @return o traje recomendado
     */
    public String getTraje() {
        return traje;
    }

    /**
     * Obtém a atração especial do festival.
     * 
     * @return a atração especial do festival
     */
    public String getAtracaoEspecial() {
        return atracao_especial;
    }

    /**
     * Método que filtra eventos como festivais com base nos trajes recomendados.
     * Retorna {@code true} se o traje fornecido for do tipo {@code EventoFestival}. 
     * 
     * @param evento Evento a ser comparado.
     * @return {@code true} se o evento possuir pelo menos um traje em comum, 
     *         {@code false} caso contrário.
     */
    @Override
    public boolean filtrar(Evento evento) {
        if (evento instanceof EventoFestival) {
            EventoFestival outro = (EventoFestival) evento;
            return this.traje.equalsIgnoreCase(outro.traje);
        }
        return false;
    }

    /**
     * Método específico para exibir detalhes do festival.
     * <p>
     * Exibe o nome do festival, local, data, traje recomendado e atração especial.
     * </p>
     */
    public void exibirDetalhes() {
        System.out.println("Evento: " + getNome());
        System.out.println("Local: " + local.getNome());
        System.out.println("Data: " + getData());
        System.out.println("Traje recomendado: " + getTraje());
        System.out.println("Atração especial: " + getAtracaoEspecial());
        System.out.println("Preço do ingresso: R$ " + getPrecoIngresso());
    }

}
