/**
 * Classe EventoShow
 * 
 * Representa um evento do tipo show, contendo informações sobre o artista e a data do evento.
 * 
 * Comentários, criação de funções relacionadas ao filtrar e outras documentações e foram gerados com auxílio de Inteligencia Artificial 
 *
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

/**
 * Classe que modela um evento do tipo show, estendendo a classe Evento.
 */
public class EventoShow extends Evento implements FiltroEventos{
    
    private String artista;

    /**
     * Construtor da classe EventoShow.
     * 
     * @param nome          o nome do show
     * @param local         o local onde será realizado
     * @param precoIngresso o valor do ingresso
     * @param categoria     a categoria do evento
     * @param data          a data do show
     * @param artista       o nome do artista principal
     */
    public EventoShow(String nome, Local local, double precoIngresso, String categoria, String data, String artista) {
        super(nome, local, precoIngresso, categoria, data);
        this.artista = artista;
    }
    /**
     * Obtém o nome do artista principal do show.
     * 
     * @return o nome do artista
     */
    public String getArtista() {
        return artista;
    }

    /**
     * Define o nome do artista principal do show.
     * 
     * @param artista o nome do artista
     */
    public void setArtista(String artista) {
        this.artista = artista;
    }

    /**
     * Método que filtra eventos como shows com base nos artistas.
     * Retorna {@code true} se o artista fornecido for do tipo {@code EventoShow}.
     * 
     * @param evento Evento a ser comparado.
     * @return {@code true} se o evento possuir pelo menos um artista em comum, 
     *         {@code false} caso contrário.
     */
    @Override
    public boolean filtrar(Evento evento) {
        if (evento instanceof EventoShow) {
            EventoShow outro = (EventoShow) evento;
            return this.artista.equalsIgnoreCase(outro.artista);
        }
        return false;
    }

    /**
     * Método específico para exibir detalhes do show.
     * <p>
     * Exibe o nome do show, local, data, artista principal e preço do ingresso.
     * </p>
     */
    public void exibirDetalhes() {
        System.out.println("Evento: " + getNome());
        System.out.println("Local: " + local.getNome());
        System.out.println("Data: " + getData());
        System.out.println("Artista principal: " + getArtista());
        System.out.println("Preço do ingresso: R$ " + getPrecoIngresso());
    }

}
