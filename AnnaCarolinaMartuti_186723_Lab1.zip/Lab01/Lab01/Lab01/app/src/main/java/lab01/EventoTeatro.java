/**
 * Classe EventoTeatro
 * 
 * Representa um evento do tipo teatro, contendo informações sobre o filme correspondente e o personagem principal.
 * 
 * Comentários, criação de funções relacionadas ao filtrar e outras documentações e foram gerados com auxílio de Inteligencia Artificial 
 *
 *  @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

/**
 * Classe que modela um evento do tipo teatro, estendendo a classe Evento.
 */
public class EventoTeatro extends Evento implements FiltroEventos{

    
    private String diretor;
    private String personagemPrincipal;

    /**
     * Construtor da classe EventoTeatro.
     * 
     * @param nome                o nome do evento teatral
     * @param local               o local onde será realizado
     * @param precoIngresso       o valor do ingresso
     * @param categoria           a categoria do evento
     * @param data                a data do evento teatral
     * @param diretor             o nome do diretor correspondente
     * @param personagemPrincipal o nome do personagem principal
     */
    public EventoTeatro(String nome, Local local, double precoIngresso, String categoria, String data, String diretor, String personagemPrincipal) {
        super(nome, local, precoIngresso, categoria, data);
        this.diretor = diretor;
        this.personagemPrincipal = personagemPrincipal;
    }

    /**
     * Obtém o nome do diretor do evento teatral.
     * 
     * @return o nome do diretor
     */
    public String getDiretor() {
        return diretor;
    }

    /**
     * Obtém o nome do personagem principal do evento teatral.
     * 
     * @return o nome do personagem principal
     */
    public String getPersonagemPrincipal() {
        return personagemPrincipal;
    }

    /**
     * Método que filtra eventos como teatros com base no diretor.
     * Retorna {@code true} se o diretor fornecido for do tipo {@code EventoTeatro}.
     * 
     * @param evento Evento a ser comparado.
     * @return {@code true} se o evento possuir pelo menos um diretor em comum, 
     *         {@code false} caso contrário.
     */
    @Override
    public boolean filtrar(Evento evento) {
        if (evento instanceof EventoTeatro) {
            EventoTeatro outroTeatro = (EventoTeatro) evento;
            return this.diretor.equals(outroTeatro.diretor);
        }
        return false;
    }

    /**
     * Método para exibir detalhes do evento teatral.
     * Exibe o nome do evento, local, data, diretor, personagem principal e preço do ingresso.
     */
    public void exibirDetalhes() {
        System.out.println("Evento: " + getNome());
        System.out.println("Local: " + local.getNome());
        System.out.println("Data: " + getData());
        System.out.println("Diretor: " + getDiretor());
        System.out.println("Personagem principal: " + getPersonagemPrincipal());
        System.out.println("Preço do ingresso: R$ " + getPrecoIngresso());
    }

}
