package lab01;

/**
 * Interface {@code FiltroEventos}.
 * 
 * Define um contrato para filtrar eventos com base em critérios específicos.
 * 
 * Comentários e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
public interface FiltroEventos {

    /**
     * Aplica um critério de filtragem a um evento.
     * 
     * @param evento o evento a ser avaliado pelo filtro
     * @return {@code true} se o evento atender aos critérios do filtro, 
     *         {@code false} caso contrário
     */
    boolean filtrar(Evento evento);
}