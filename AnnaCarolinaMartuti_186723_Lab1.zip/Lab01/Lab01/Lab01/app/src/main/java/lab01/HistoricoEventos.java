package lab01;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Classe {@code HistoricoEventos}.
 * 
 * Responsável por armazenar e gerenciar o histórico de eventos, permitindo a busca por categoria e data.
 * 
 * Comentários, algumas funções e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
public class HistoricoEventos {
    
    private List<Evento> eventos;

    /**
     * Construtor padrão que inicializa a lista de eventos.
     */
    public HistoricoEventos() {
        eventos = new ArrayList<>();
    }

    /**
     * Adiciona um evento ao histórico.
     * 
     * @param evento o evento a ser adicionado
     */
    public void adicionarEvento(Evento evento) {
        eventos.add(evento);
    }

    /**
     * Busca eventos por tipo (categoria).
     * 
     * @param categoria a classe da categoria do evento (ex: {@code EventoShow.class})
     * @return uma lista de eventos da categoria especificada
     */
    public List<Evento> buscarEventosPorTipo(Class<?> categoria) {
        return eventos.stream()
                      .filter(evento -> evento.getClass().equals(categoria))
                      .collect(Collectors.toList());
    }

    /**
     * Busca eventos por data.
     * 
     * @param data a data desejada no formato correspondente ao método {@code getData()} de {@code Evento}
     * @return uma lista de eventos que ocorrem na data especificada
     */
    public List<Evento> buscarEventosPorData(String data) {
        return eventos.stream()
                      .filter(evento -> evento.getData().equals(data))
                      .collect(Collectors.toList());
    }

    /**
     * Obtém a lista completa de eventos armazenados.
     * 
     * @return uma lista contendo todos os eventos registrados
     */
    public List<Evento> getEventos() {
        return eventos;
    }
}
