/**
 * Classe Ingresso
 * 
 * Representa um ingresso para um evento, contendo informações sobre o evento associado.
 * 
 * Comentários, código random e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Gabriel Leite - 216180
 * @author Caio Rhoden - 214129
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

import java.util.Random;

/**
 * Classe abstrata que modela um ingresso.
 */
public abstract class Ingresso {

    private Evento evento;
    private String id;

    /**
     * Construtor da classe Ingresso.
     * 
     * @param evento o evento associado ao ingresso
     * 
     * o id foi criado como um identificador unico e aleatório, nao sendo necessário sua passagem como parametro
     */
    public Ingresso(Evento evento) {
        this.evento = evento;
        this.id = String.valueOf(new Random().nextInt(10000));
    }

    /**
     * Retorna o evento associado ao ingresso.
     * 
     * @return o evento do ingresso
     */
    public Evento getEvento() {
        return this.evento;
    }

    /**
     * Retorna o identificador do ingresso.
     *
     * @return o ID do ingresso
     */
    public String getId() {
        return this.id;
    }

    /**
     * Retorna o preço do ingresso.
     * 
     * @return o preço do ingresso
     */
    public abstract double getPreco();
}
