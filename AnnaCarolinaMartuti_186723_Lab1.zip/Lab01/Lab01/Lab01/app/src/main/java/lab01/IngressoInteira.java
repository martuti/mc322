package lab01;

/**
 * Representa um ingresso do tipo inteira para um evento.
 * 
 * Comentários e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 */

public class IngressoInteira extends Ingresso {

    /**
     * Construtor da classe IngressoInteira.
     * 
     * @param evento o evento associado ao ingresso
     */
    public IngressoInteira(Evento evento) {
        super(evento);
    }

    /**
     * Retorna o preço integral do ingresso.
     * 
     * @return o preço do ingresso sem descontos
     */
    @Override
    public double getPreco() {
        return getEvento().getPrecoIngresso(); 
    }
}
