/**
 * Classe IngressoMeia
 * 
 * Representa um ingresso com desconto de 50% sobre o preço original.
 * 
 * Comentários e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 * @version 1.0
 */
package lab01;

/**
 * Classe concreta que representa um ingresso do tipo meia-entrada.
 */
public class IngressoMeia extends Ingresso {

    /**
     * Construtor da classe IngressoMeia.
     * 
     * @param evento o evento associado ao ingresso
     */
    public IngressoMeia(Evento evento) {
        super(evento);
    }

    /**
     * Retorna o preço do ingresso meia-entrada, que é metade do preço original.
     * 
     * @return o preço do ingresso meia-entrada
     */
    @Override
    public double getPreco() {
        return getEvento().getPrecoIngresso() / 2; 
    }
}
