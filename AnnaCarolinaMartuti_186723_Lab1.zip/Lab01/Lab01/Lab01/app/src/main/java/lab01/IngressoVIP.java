package lab01;

/**
 * Representa um ingresso VIP para um evento.
 * Este ingresso tem um preço dobrado em relação ao valor padrão do evento.
 * 
 * Comentários e outras documentações foram gerados com auxílio de Inteligencia Artificial
 * 
 * @author Anna Carolina Martuti - 186723
 */
public class IngressoVIP extends Ingresso {

    /**
     * Construtor da classe IngressoVIP.
     * 
     * @param evento o evento associado ao ingresso VIP
     */
    public IngressoVIP(Evento evento) {
        super(evento);
    }

    /**
     * Retorna o preço do ingresso VIP, que é o dobro do preço do ingresso normal.
     * 
     * @return o preço do ingresso VIP
     */
    @Override
    public double getPreco() {
        return getEvento().getPrecoIngresso() * 2;
    }
}
