/*
 * Usuario.java
 * 
 * Material usado na disciplina MC322 - Programação orientada a objetos.
 */
package lab01;

/**
 * Contém a estrutura de implementação de um Usuario.
 * 
 * @author Gabriel Leite - 216180
 * @author Caio Rhoden - 214129
 * @author Anna Carolina Martuti - 186723
 */
public class Usuario {

    private String nome;
    private String email;
    private Ingresso ingresso; // Adicionado para seguir o UML

    /**
     * Construtor da classe Usuario
     * @param nome o nome do usuário
     * @param email o email do usuário
     */
    public Usuario(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.ingresso = null; // Inicialmente, o usuário não tem ingresso
    }

    /**
     * Retorna o nome do usuário
     * @return o nome do usuário
     */
    public String getNome() {
        return nome;
    }

    /**
     * Altera o nome do usuário para `nome` 
     * @param nome o novo nome do usuário
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Retorna o email do usuário
     * @return o email do usuário
     */
    public String getEmail() {
        return email;
    }

    /**
     * Altera o email do usuário para `email`
     * @param email o novo email do usuário
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Retorna o ingresso do usuário
     * @return o ingresso do usuário
     */
    public Ingresso getIngresso() {
        return ingresso;
    }

    /**
     * Associa um ingresso ao usuário
     * @param ingresso o ingresso que será associado ao usuário
     */
    public void setIngresso(Ingresso ingresso) {
        this.ingresso = ingresso;
    }

    /**
     * Adiciona um ingresso ao usuário.
     * Se o usuário já possui um ingresso, ele é substituído pelo novo.
     * 
     * @param ingresso o ingresso a ser adicionado
     */
    public void adicionarIngresso(Ingresso ingresso) {
        this.ingresso = ingresso;
    }
}