package lab01;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
/*
 * Em TODAS as chamadas de EventoShow foi adicionado os parametros faltantes com base na respectiva classe.
 */

public class Lab01Test {

    /**
     * Testa se o getCapacidadeEvento retorna a capacidade do local do Evento
    
        Foi realizada uma mudança ao chamar a função getCapacidade para que encaixasse na abordagem definida na classe local.
     
     */
    @Test
    public void getCapacidadeEventoShow() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento = new EventoShow("MPB em Campinas", testLocal, 150, "Djavan", "01/05/2025", "Artista Anavitoria");
        assertEquals(2000, testEvento.local.getCapacidade());
    }


    /**
     * Testa o get e seter do EventoShow para o atributo artista
     * Espera-se a troca de "01/05/2025" por "Anavitória"
     */

    @Test
    public void setAndGetArtistaEventoShow() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento = new EventoShow("MPB em Campinas", testLocal, 150, "Djavan", "01/05/2025", "Artista Anavitoria");
        testEvento.setArtista("Anavitória");
        assertEquals("Anavitória", testEvento.getArtista());
    }

    /**
     * Testa o método getPreco para o IngressoMeia
     * Espera o retorno da metade do valor (100) do ingresso do EventoShow criado (200)
     */

    @Test
    public void getPrecoIngressoMeia() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento = new EventoShow("MPB em Campinas", testLocal, 200, "Djavan", "01/05/2025", "Artista Anavitoria");
        IngressoMeia ingressoMeia = new IngressoMeia(testEvento);
        assertEquals(100, ingressoMeia.getPreco());
    }


    /**
     * Testa o método getPreco para o IngressoInteira
     * Espera o retorno do valor (250) do ingresso do EventoShow criado
     */
    @Test
    public void getPrecoIngressoInteira() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento = new EventoShow("MPB em Campinas", testLocal, 250, "Djavan", "01/05/2025", "Artista Anavitoria");
        IngressoInteira ingressoInteira = new IngressoInteira(testEvento);
        assertEquals(250, ingressoInteira.getPreco());
    }

    /**
     * Testa o método adicionarIngressoMeia
     * Verifica se o ingresso foi adicionado à lista de ingressos vendidos
     * e se o usuario agora tem o ingresso
    */
    @Test
    public void adicionarIngressoMeia() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento = new EventoShow("MPB em Campinas", testLocal, 200, "Djavan", "01/05/2025", "artista blabla");
        IngressoMeia ingressoMeia = new IngressoMeia(testEvento);
        Usuario usuarioTest = new Usuario("Gabriel", "gabriel@me.com");
        testEvento.adicionarIngresso(ingressoMeia, usuarioTest);
        assertEquals(1, testEvento.getIngressosVendidos().size());
        assertEquals(ingressoMeia, usuarioTest.getIngresso());

    }
        
    
    /**
     * Testa o método adicionarEvento do HistoricoEventos
     * Verifica se os dois eventos foram adicionados à lista de eventos
     * do HistoricoEventos
     */
    @Test
    public void adicionaEventoemHistorico() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento1 = new EventoShow("MPB em Campinas", testLocal, 200, "Djavan", "01/05/2025", "Artista Anavitoria");
        EventoShow testEvento2 = new EventoShow("MPB em Campinas", testLocal, 200, "Anavitória", "02/05/2025", "Artista Anavitoria");
        HistoricoEventos historicoTeste = new HistoricoEventos();
        historicoTeste.adicionarEvento(testEvento1);
        historicoTeste.adicionarEvento(testEvento2);
        assertEquals(2, historicoTeste.getEventos().size());

    }
        

    /**
     * Testa o método buscarEventosPorTipo do HistoricoEventos
     * Verifica se os dois eventos do tipo EventoShow foram encontrados
     * pela busca
     */
    @Test
    public void buscarEventosPorTipo() {

        Local testLocal = new Local("Teatro Castro Mendes", 2000);
        EventoShow testEvento1 = new EventoShow("MPB em Campinas", testLocal, 200, "Djavan", "01/05/2025", "artista Anavitória");
        EventoShow testEvento2 = new EventoShow("MPB em Campinas", testLocal, 200, "Anavitória", "02/05/2025", "artista vitori e Ana");        
        HistoricoEventos historicoTeste = new HistoricoEventos();
        historicoTeste.adicionarEvento(testEvento1);
        historicoTeste.adicionarEvento(testEvento2);
        assertEquals(2, historicoTeste.buscarEventosPorTipo(EventoShow.class).size());
    }
        
}
